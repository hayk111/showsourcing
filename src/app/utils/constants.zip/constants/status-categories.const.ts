export const statusCategories = [
	{
		'id': 'inProgress',
		'name': 'inProgress'
	},
	{
		'id': 'validated',
		'name': 'validated'
	},
	{
		'id': 'refused',
		'name': 'refused'
	},
];
