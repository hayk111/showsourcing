export const businessTypes = [
	{
		'id': 'Manufacturer',
		'name': 'Manufacturer'
	},
	{
		'id': 'Supplier',
		'name': 'Supplier'
	},
	{
		'id': 'Trader',
		'name': 'Trader'
	},
];
