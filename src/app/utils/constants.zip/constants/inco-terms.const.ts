export const incoTerms = [
	{
		'id': 'EXW',
		'name': 'EXW'
	},
	{
		'id': 'FCA',
		'name': 'FCA'
	},
	{
		'id': 'FAS',
		'name': 'FAS'
	},
	{
		'id': 'FOB',
		'name': 'FOB'
	},
	{
		'id': 'CFR',
		'name': 'CFR'
	},
	{
		'id': 'CIF',
		'name': 'CIF'
	},
	{
		'id': 'CPT',
		'name': 'CPT'
	},
	{
		'id': 'CIP',
		'name': 'CIP'
	},
	{
		'id': 'DAT',
		'name': 'DAT'
	},
	{
		'id': 'DAP',
		'name': 'DAP'
	},
	{
		'id': 'DDP',
		'name': 'DDP'
	}
];
