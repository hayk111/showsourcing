export const categories = [
	{
		'id': 'Electronic',
		'name': 'Electronic'
	},
	{
		'id': 'Textile',
		'name': 'Textile'
	},
	{
		'id': 'Gadgets',
		'name': 'Gadgets'
	},
	{
		'id': 'Technology',
		'name': 'Technology'
	}
];
