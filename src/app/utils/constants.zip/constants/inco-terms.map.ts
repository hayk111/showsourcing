export const incoTermsMap = {
	'EXW': {
		'id': 'EXW',
		'name': 'EXW'
	},
	'FCA': {
		'id': 'FCA',
		'name': 'FCA'
	},
	'FAS': {
		'id': 'FAS',
		'name': 'FAS'
	},
	'FOB': {
		'id': 'FOB',
		'name': 'FOB'
	},
	'CFR': {
		'id': 'CFR',
		'name': 'CFR'
	},
	'CIF': {
		'id': 'CIF',
		'name': 'CIF'
	},
	'CPT': {
		'id': 'CPT',
		'name': 'CPT'
	},
	'CIP': {
		'id': 'CIP',
		'name': 'CIP'
	},
	'DAT': {
		'id': 'DAT',
		'name': 'DAT'
	},
	'DAP': {
		'id': 'DAP',
		'name': 'DAP'
	},
	'DDP': {
		'id': 'DDP',
		'name': 'DDP'
	}
};
